"""V15 prototype: millimetres. Run `python build.py` with CadQuery 2.7.x and numpy.
Screw hardware dimensions remain provisional; see README_JA.md.
"""
import os;os.environ.setdefault('XDG_CACHE_HOME','/tmp/watch_cad_cache')
from pathlib import Path
import cadquery as cq,json
from mesh_cleanup import clean_stl
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'export';OUT.mkdir(exist_ok=True)
QA=ROOT/'qa';QA.mkdir(exist_ok=True)
DROP=.50; SEAT=3.99; PAD_D=8.;PAD_BOTTOM=.8;HEAD_BEARING=2.3
SHAFT_D=2.4;HEAD_D=4.4; CENTERS=(-20.,20.)
def slab(a,b):return cq.Workplane('XY').box(160,160,b-a).val().translate((0,0,(a+b)/2))
s=cq.importers.importStep(str(ROOT/'inputs/V14_source.step')).val()
low=s.intersect(slab(-20,3.49));high=s.intersect(slab(3.99,40)).translate((0,0,-DROP))
p=low.fuse(high).clean();lowered=p
pads=[]
for x in CENTERS:
 pad=cq.Solid.makeCylinder(PAD_D/2,SEAT-PAD_BOTTOM,cq.Vector(x,0,PAD_BOTTOM));pads.append(pad);p=p.fuse(pad)
for x in CENTERS:
 p=p.cut(cq.Solid.makeCylinder(SHAFT_D/2,10,cq.Vector(x,0,-1)))
 p=p.cut(cq.Solid.makeCylinder(HEAD_D/2,HEAD_BEARING+5,cq.Vector(x,0,-5)))
p=p.clean()
assert p.isValid() and len(p.Solids())==1
step=OUT/'M5Stopwatch_V15_LOW_SCREW_PROTOTYPE.step'
stl=OUT/'M5Stopwatch_V15_LOW_SCREW_PROTOTYPE.stl'
bb=p.BoundingBox()
cq.exporters.export(p,str(step));cq.exporters.export(p,str(stl),tolerance=.01,angularTolerance=.05)
mesh=clean_stl(stl)
assert mesh['boundary_edges']==mesh['nonmanifold_edges']==mesh['orientation_conflicts']==0
v=cq.importers.importStep(str(ROOT/'inputs/receiver_void_extended.step')).val()
watch=[q.rotate((0,0,0),(0,1,0),-90).translate((0,0,SEAT)) for q in cq.importers.importStep(str(ROOT/'inputs/StopWatch.step')).vals()]
sound_region=cq.Workplane('XY').box(70,30,25).val().translate((0,25,10))
# All sound-path surfaces in y>=10 match the height-reduced source exactly.
sound_a=p.intersect(sound_region);sound_b=lowered.intersect(sound_region)
report={'valid':p.isValid(),'solids':len(p.Solids()),'volume_mm3':p.Volume(),'bbox_xyz_mm':[bb.xlen,bb.ylen,bb.zlen],'bbox_z_mm':[bb.zmin,bb.zmax],'central_wrist_datum_to_watch_top_mm':19.49,'whole_assembly_bbox_height_mm':19.49-bb.zmin,'receiver_void_overlap_mm3':p.intersect(v).Volume(),'watch_overlap_mm3':[p.intersect(w).Volume() for w in watch],'pad_to_receiver_void_distance_mm':[q.distance(v) for q in pads],'sound_region_added_mm3':sound_a.cut(sound_b).Volume(),'sound_region_removed_mm3':sound_b.cut(sound_a).Volume(),'parameters':{'height_reduction_from_V14':DROP,'body_backside_z':SEAT,'pad_diameter':PAD_D,'pad_bottom_z':PAD_BOTTOM,'head_bearing_z':HEAD_BEARING,'bearing_web_thickness':SEAT-HEAD_BEARING,'shaft_hole_diameter_PROVISIONAL':SHAFT_D,'head_recess_diameter_PROVISIONAL':HEAD_D,'head_recess_depth':HEAD_BEARING-PAD_BOTTOM,'screw_centers':[[x,0] for x in CENTERS]},'mesh':mesh,'limits':'Prototype, hardware unmeasured. No physical fit/strength/print-success validation; no torque specification.'}
assert report['receiver_void_overlap_mm3']<1e-7 and max(report['watch_overlap_mm3'])<1e-7
assert report['sound_region_added_mm3']<1e-7 and report['sound_region_removed_mm3']<1e-7
(QA/'build_validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
