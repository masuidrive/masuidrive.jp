import os;os.environ['XDG_CACHE_HOME']='/tmp/watchqa'
import cadquery as c,json,hashlib,math
from pathlib import Path
R=Path(__file__).resolve().parent;O=R/'qa'
path=R/'export/M5Stopwatch_V15_LOW_SCREW_PROTOTYPE.step';s=c.importers.importStep(str(path)).val();old=c.importers.importStep(str(R/'inputs/V14_source.step')).val();v=c.importers.importStep(str(R/'inputs/receiver_void_extended.step')).val()
watch=[w.rotate((0,0,0),(0,1,0),-90).translate((0,0,3.99)) for w in c.importers.importStep(str(R/'inputs/StopWatch.step')).vals()]
def box(x,y,z,dx,dy,dz):return c.Workplane('XY').box(dx,dy,dz).val().translate((x,y,z))
r={'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'valid':s.isValid(),'solids':len(s.Solids()),'receiver_overlap_mm3':s.intersect(v).Volume(),'watch_overlap_mm3':[s.intersect(w).Volume() for w in watch]}
# Acoustic region exact shape equality to V14 moved down, then sectional clear-area check.
reg=box(0,20,6,12,26,5)
a=s.intersect(reg);b=old.translate((0,0,-.5)).intersect(reg)
r['acoustic_region_symmetric_difference_mm3']=a.cut(b).Volume()+b.cut(a).Volume()
r['acoustic_sections']=[]
for y in [15.8,17,19,21,23,24,25,25.5,26,26.5,27,28]:
 slab=box(0,y,4.39,11,.02,.8);free=slab.cut(s)
 for w in watch:free=free.cut(w)
 r['acoustic_sections'].append({'y_mm':y,'free_area_mm2':free.Volume()/.02,'pieces':len(free.Solids())})
r['screw_z_sections']=[]
for x in [-20,20]:
 for radius in [0,1.3,2.0,2.3,3.5]:
  cyl=c.Solid.makeCylinder(.01,12,c.Vector(x+radius,0,-1));q=s.intersect(cyl)
  r['screw_z_sections'].append({'center_x':x,'radial_mm':radius,'solid_intervals_z_mm':[[t.BoundingBox().zmin,t.BoundingBox().zmax] for t in q.Solids()]})
# Receiver upper extreme vs underside floor and sampled vertical ceiling thickness.
r['receiver_void_zmax']=v.BoundingBox().zmax
r['seat_z']=3.99;r['seat_minus_receiver_zmax_mm']=3.99-v.BoundingBox().zmax
r['roof_columns']=[]
for x in [-9,-4,0,4,9]:
 for y in [-20,-19,-18,-17,-16,-15,15,16,17,18,19,20]:
  tube=c.Solid.makeCylinder(.005,12,c.Vector(x,y,-5));q=v.intersect(tube)
  if q.Volume()>1e-9:
   z=q.BoundingBox().zmax
   above=c.Solid.makeCylinder(.005,5,c.Vector(x,y,z+1e-4));roof=s.intersect(above)
   intervals=[[t.BoundingBox().zmin,t.BoundingBox().zmax] for t in roof.Solids()]
   r['roof_columns'].append({'x':x,'y':y,'void_top':z,'solid_intervals_above':intervals})
(O/'results.json').write_text(json.dumps(r,indent=2));print(json.dumps({k:v for k,v in r.items() if k!='roof_columns'},indent=2))
