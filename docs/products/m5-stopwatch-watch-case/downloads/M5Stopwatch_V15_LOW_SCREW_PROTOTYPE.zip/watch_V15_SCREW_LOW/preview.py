from pathlib import Path
import cadquery as cq,numpy as np,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
R=Path(__file__).resolve().parent
s=cq.importers.importStep(str(R/'export/M5Stopwatch_V15_LOW_SCREW_PROTOTYPE.step')).val()
import struct
raw=(R/'export/M5Stopwatch_V15_LOW_SCREW_PROTOTYPE.stl').read_bytes();count=struct.unpack_from('<I',raw,80)[0];dt=np.dtype([('n','<f4',(3,)),('v','<f4',(3,3)),('a','<u2')]);v=np.frombuffer(raw,dt,count=count,offset=84)['v'].astype(float).reshape(-1,3);f=np.arange(len(v)).reshape(-1,3)
tri=v[f];n=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);lens=np.linalg.norm(n,axis=1);n=n/np.maximum(lens[:,None],1e-12);light=np.array([.3,-.4,1.]);light/=np.linalg.norm(light);shade=.45+.55*np.abs(n@light);colors=np.column_stack([shade*.42,shade*.68,shade*.78,np.ones(len(shade))])
fig=plt.figure(figsize=(13,6),facecolor='white')
for i,(el,az,title) in enumerate([(40,-55,'V15 / top: sound path retained'),(-65,-55,'V15 / underside: two screw seats')]):
 ax=fig.add_subplot(1,2,i+1,projection='3d');ax.add_collection3d(Poly3DCollection(v[f],facecolors=colors,edgecolors='none',alpha=1))
 ax.set(xlim=(-30,30),ylim=(-30,30),zlim=(-5,10),xlabel='X (mm)',ylabel='Y (mm)',zlabel='Z (mm)');ax.set_box_aspect((60,60,15));ax.view_init(el,az);ax.set_title(title);ax.set_axis_off()
fig.suptitle('PROTOTYPE / screw dimensions require measurement / not physically verified',fontsize=12)
fig.tight_layout();fig.savefig(R/'preview/V15_overview.png',dpi=180)
