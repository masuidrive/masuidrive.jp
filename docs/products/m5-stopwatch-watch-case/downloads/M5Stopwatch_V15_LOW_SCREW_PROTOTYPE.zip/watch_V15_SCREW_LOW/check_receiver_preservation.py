import os;os.environ['XDG_CACHE_HOME']='/tmp/watchqa'
import cadquery as c,json
from pathlib import Path
R=Path(__file__).resolve().parent;O=R/'qa'; s=c.importers.importStep(str(R/'export/M5Stopwatch_V15_LOW_SCREW_PROTOTYPE.step')).val();old=c.importers.importStep(str(R/'inputs/V14_source.step')).val()
r=[]
for y in [-20,20]:
 region=c.Workplane('XY').box(100,20,23).val().translate((0,y,-8.5));a=s.intersect(region);b=old.intersect(region);r.append({'region':'X +/-50; Y '+str(y)+' +/-10; Z -20..3','removed_mm3':b.cut(a).Volume(),'added_mm3':a.cut(b).Volume()})
(O/'receiver_preservation.json').write_text(json.dumps(r,indent=2));print(r)
