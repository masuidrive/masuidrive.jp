"""Remove numerically degenerate / duplicate STL facets; weld at1e-5mm.
Only print tessellation is cleaned. STEP geometry is never changed.
"""
from pathlib import Path
import struct,numpy as np,json
from collections import Counter

def clean_stl(path,tol=1e-5):
 p=Path(path);raw=p.read_bytes();n=struct.unpack_from('<I',raw,80)[0]
 if len(raw)!=84+50*n:raise ValueError('Expected binary STL: '+str(p))
 dt=np.dtype([('normal','<f4',(3,)),('v','<f4',(3,3)),('attr','<u2')]);a=np.frombuffer(raw,dt,count=n,offset=84)
 coords=a['v'].astype(float).reshape(-1,3)
 quant=np.rint(coords/tol).astype(np.int64)
 keys,idx,inv=np.unique(quant,axis=0,return_index=True,return_inverse=True)
 v=coords[idx];f=inv.reshape(-1,3)
 good=(f[:,0]!=f[:,1])&(f[:,1]!=f[:,2])&(f[:,2]!=f[:,0])
 area=np.linalg.norm(np.cross(v[f[:,1]]-v[f[:,0]],v[f[:,2]]-v[f[:,0]]),axis=1)
 good &= area>1e-10
 f=f[good]
 _,ids=np.unique(np.sort(f,axis=1),axis=0,return_index=True);f=f[np.sort(ids)]
 norms=np.cross(v[f[:,1]]-v[f[:,0]],v[f[:,2]]-v[f[:,0]])
 norms/=np.linalg.norm(norms,axis=1)[:,None]
 data=np.zeros(len(f),dtype=dt);data['normal']=norms;data['v']=v[f]
 p.write_bytes(b'CAD print mesh: degenerate facets removed; units mm'.ljust(80,b' ')+struct.pack('<I',len(f))+data.tobytes())
 edges=Counter(tuple(sorted(e)) for tri in f for e in [(int(tri[0]),int(tri[1])),(int(tri[1]),int(tri[2])),(int(tri[2]),int(tri[0]))])
 directed=Counter((int(a),int(b)) for tri in f for a,b in [(tri[0],tri[1]),(tri[1],tri[2]),(tri[2],tri[0])])
 conflicts=sum(1 for (a,b),c in edges.items() if c==2 and (directed[(a,b)]!=1 or directed[(b,a)]!=1))
 return {'file':p.name,'original_facets':n,'clean_facets':len(f),'removed_facets':n-len(f),'weld_tolerance_mm':tol,'boundary_edges':sum(c==1 for c in edges.values()),'nonmanifold_edges':sum(c>2 for c in edges.values()),'orientation_conflicts':conflicts}
if __name__=='__main__':
 import sys
 root=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).parent/'export'
 results=[clean_stl(p) for p in sorted(root.glob('*.stl'))]
 print(json.dumps(results,indent=2));(root.parent/'mesh_validation.json').write_text(json.dumps(results,indent=2))
