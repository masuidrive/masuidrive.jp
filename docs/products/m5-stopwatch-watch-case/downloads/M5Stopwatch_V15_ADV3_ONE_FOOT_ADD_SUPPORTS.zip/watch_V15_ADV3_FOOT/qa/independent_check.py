import os;os.environ['XDG_CACHE_HOME']='/tmp/indfootcache'
import cadquery as c,json,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent.parent;Q=R/'qa'; lift=24.182686002179846
f=R/'export/M5Stopwatch_V15_ADV3_tilt30_ONE_FOOT_ADD_SUPPORTS.step';p=c.importers.importStep(str(f)).val()
def tr(s):return s.rotate((0,0,0),(0,1,0),-60).translate((0,0,lift))
b=tr(c.importers.importStep(str(R/'inputs/V15_body.step')).val());old=tr(c.importers.importStep(str(R/'inputs/V14_source.step')).val());oldp=c.importers.importStep(str(R/'inputs/V14_with_foot.step')).val();foot=oldp.cut(old).clean();added=p.cut(b).clean();v=tr(c.importers.importStep(str(R/'inputs/receiver_void_extended.step')).val())
r={'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'valid':p.isValid(),'solid_count':len(p.Solids()),'lost_body_mm3':b.cut(p).Volume(),'added_equals_original_foot_delta_mm3':added.cut(foot).Volume()+foot.cut(added).Volume(),'added_in_void_mm3':added.intersect(v).Volume(),'foot_body_distance_mm':foot.distance(b),'body_min_z_mm':b.BoundingBox().zmin,'minimum_z_mm':p.BoundingBox().zmin,'bbox_mm':[p.BoundingBox().xlen,p.BoundingBox().ylen,p.BoundingBox().zlen]}
r['added_in_screw_voids_mm3']=[]
for x in [-20,20]:
 for rad,z,h in [(1.2,-1,10),(2.2,-5,7.3)]:r['added_in_screw_voids_mm3'].append(added.intersect(tr(c.Solid.makeCylinder(rad,h,c.Vector(x,0,z)))).Volume())
ac=c.importers.importStep(str(R/'inputs/V14_acoustic_cutter.step')).val().translate((0,0,-.5));r['added_in_acoustic_cutter_mm3']=added.intersect(tr(ac)).Volume()
# Shared face area establishes face-connected rather than only edge/point touching union.
contacts=[]
for a in foot.Faces():
 ba=a.BoundingBox()
 for bbface in b.Faces():
  bb=bbface.BoundingBox()
  if any([ba.xmax<bb.xmin-1e-6,bb.xmax<ba.xmin-1e-6,ba.ymax<bb.ymin-1e-6,bb.ymax<ba.ymin-1e-6,ba.zmax<bb.zmin-1e-6,bb.zmax<ba.zmin-1e-6]):continue
  q=a.intersect(bbface)
  if q.Area()>1e-8:contacts.append({'area_mm2':q.Area(),'center':q.Center().toTuple(),'bbox':[q.BoundingBox().xlen,q.BoundingBox().ylen,q.BoundingBox().zlen]})
r['shared_face_contacts']=contacts;r['total_shared_face_area_mm2']=sum(a['area_mm2'] for a in contacts)
r['scope']='Geometry only; additional slicer supports needed. No printing/strength validation.'
(Q/'independent_validation.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
