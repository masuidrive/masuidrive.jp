import os;os.environ['XDG_CACHE_HOME']='/tmp/neckcache'
import cadquery as c,json
from pathlib import Path
R=Path('watch_V15_ADV3_FOOT');p=c.importers.importStep(str(R/'export/M5Stopwatch_V15_ADV3_tilt30_ONE_FOOT_ADD_SUPPORTS.step')).val();old=c.importers.importStep(str(R/'inputs/V14_with_foot.step')).val();reg=c.Workplane('XY').box(1.5,.65,1.0).val().translate((-16.3,0,2.1));a=p.intersect(reg);b=old.intersect(reg);r={'region_center':[-16.3,0,2.1],'region_size_mm':[1.5,.65,1.0],'added_mm3':a.cut(b).Volume(),'removed_mm3':b.cut(a).Volume(),'meaning':'Foot/body junction geometry unchanged within enclosing local region.'};(R/'qa/independent_neck_compare.json').write_text(json.dumps(r,indent=2));print(r)
