from pathlib import Path
import struct,json,numpy as np
R=Path(__file__).resolve().parent
p=R/'export/M5Stopwatch_V15_ADV3_tilt30_ONE_FOOT_ADD_SUPPORTS.stl';raw=p.read_bytes();n=struct.unpack_from('<I',raw,80)[0]
dt=np.dtype([('normal','<f4',(3,)),('v','<f4',(3,3)),('attr','<u2')]);a=np.frombuffer(raw,dt,count=n,offset=84);verts=a['v'].astype(float)
v,inv=np.unique(verts.reshape(-1,3),axis=0,return_inverse=True);f=inv.reshape(-1,3)
edges=np.concatenate((f[:,[0,1]],f[:,[1,2]],f[:,[2,0]]));unique,counts=np.unique(np.sort(edges,axis=1),axis=0,return_counts=True)
parent=np.arange(len(v))
def find(a):
 while parent[a]!=a:parent[a]=parent[parent[a]];a=parent[a]
 return a
for a,b in unique:
 a=find(a);b=find(b)
 if a!=b:parent[a]=b
components=len(set(find(i) for i in range(len(v))))
vol=float(np.einsum('ij,ij->i',verts[:,0],np.cross(verts[:,1],verts[:,2])).sum()/6)
import cadquery as c
cadvol=c.importers.importStep(str(R/'export/M5Stopwatch_V15_ADV3_tilt30_ONE_FOOT_ADD_SUPPORTS.step')).val().Volume()
r={'vertices':len(v),'triangles':n,'edges':len(unique),'boundary_edges':int((counts==1).sum()),'nonmanifold_edges':int((counts>2).sum()),'connected_components':components,'signed_mesh_volume_mm3':vol,'cad_volume_mm3':cadvol,'volume_relative_error':abs(vol-cadvol)/cadvol,'bbox_mm':(v.max(0)-v.min(0)).tolist(),'finite_vertices':bool(np.isfinite(v).all()),'scope':'STL topology, connectedness, orientation (build report) and volume consistency. No exhaustive triangle-triangle self-intersection or physical strength proof.'}
assert components==1 and r['boundary_edges']==r['nonmanifold_edges']==0 and vol>0 and r['volume_relative_error']<.001
(R/'qa/mesh_crosscheck.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
