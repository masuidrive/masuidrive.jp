import os;os.environ['XDG_CACHE_HOME']='/tmp/footcache'
from pathlib import Path
import cadquery as c,json,hashlib
from mesh_cleanup import clean_stl
R=Path(__file__).resolve().parent;O=R/'export';O.mkdir(exist_ok=True);Q=R/'qa';Q.mkdir(exist_ok=True)
LIFT=24.182686002179846
body=c.importers.importStep(str(R/'inputs/V15_body.step')).val()
old=c.importers.importStep(str(R/'inputs/V14_source.step')).val()
combined_old=c.importers.importStep(str(R/'inputs/V14_with_foot.step')).val()
def orient(s):return s.rotate((0,0,0),(0,1,0),-60).translate((0,0,LIFT))
def inverse(s):return s.translate((0,0,-LIFT)).rotate((0,0,0),(0,1,0),60)
old_print=orient(old);body_print=orient(body)
# Recover the original breakaway support exactly, excluding original body material.
foot=combined_old.cut(old_print).clean()
p=body_print.fuse(foot).clean()
assert p.isValid() and len(p.Solids())==1
bb=p.BoundingBox();void=orient(c.importers.importStep(str(R/'inputs/receiver_void_extended.step')).val())
r={'valid':p.isValid(),'solids':len(p.Solids()),'rotation_Y_degrees':-60,'lift_mm':LIFT,'body_min_z_mm':body_print.BoundingBox().zmin,'minimum_z_mm':bb.zmin,'bbox_mm':[bb.xlen,bb.ylen,bb.zlen],'lost_V15_body_volume_mm3':body_print.cut(p).Volume(),'added_volume_mm3':p.cut(body_print).Volume(),'added_solid_count':len(p.cut(body_print).Solids()),'foot_volume_mm3':foot.Volume(),'foot_in_receiver_void_mm3':foot.intersect(void).Volume(),'foot_intersection_with_V15_body_mm3':foot.intersect(body_print).Volume(),'foot_parameters_from_original':{'base_mm':[10,8,.6],'breakaway_neck_mm':[.7,.45]},'print_status':'Additional slicer supports required. Not sliced; not print verified.'}
assert r['lost_V15_body_volume_mm3']<1e-7 and r['foot_in_receiver_void_mm3']<1e-7 and abs(bb.zmin)<1e-6
assert max(r['bbox_mm'])<150
step=O/'M5Stopwatch_V15_ADV3_tilt30_ONE_FOOT_ADD_SUPPORTS.step';stl=step.with_suffix('.stl')
c.exporters.export(p,str(step));c.exporters.export(p,str(stl),tolerance=.01,angularTolerance=.05)
r['mesh']=clean_stl(stl);assert all(r['mesh'][k]==0 for k in ['boundary_edges','nonmanifold_edges','orientation_conflicts'])
r['step_reimport_valid']=c.importers.importStep(str(step)).val().isValid();r['STEP_sha256']=hashlib.sha256(step.read_bytes()).hexdigest();r['STL_sha256']=hashlib.sha256(stl.read_bytes()).hexdigest()
(Q/'validation.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
